<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>PEMBELIAN</title>
</head>
<body>
<table class="table table-dark table-striped">
<thead>
    <tr>
      <th scope="col">NO</th>
      <th scope="col">ayam</th>
      <th scope="col">ayam goreng</th>
      <th scope="col">ayam panggang</th>
      <th scope="col">total bayar</th>
      <th scope="col">aksi</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $pembelian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($data->id); ?></th>
      <td><?php echo e($data->ayam); ?></td>
      <td><?php echo e($data->ayam_goreng); ?></td>
      <td><?php echo e($data->ayam_panggang); ?></td>
      <td><?php echo e($data->total_harga); ?></td>
      <td><a href="/edit/<?php echo e($data->id); ?>">Edit</a></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
</body>
</html><?php /**PATH C:\laragon\www\rest-api\resources\views/dashbord.blade.php ENDPATH**/ ?>