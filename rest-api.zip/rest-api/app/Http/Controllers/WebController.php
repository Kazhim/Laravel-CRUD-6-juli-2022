<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pembelian;

class WebController extends Controller
{
    public function tampilan()
    {
        $data['pembelian'] = Pembelian::get();
        return view('dashbord', $data);
       
    }
    public function edit($id)
    {
        $data['pembelian'] = pembelian::find($id);

        return view('edit', $data);
    }
    public function update(Request $request)
    {
        $update = Pembelian::where('id',$request->id)->update([
            'ayam' => $request->ayam,
            'ayam_goreng' => $request->ayam_goreng,
            'ayam_panggang' => $request->ayam_panggang,
            'total_harga' => $request->total_harga,
        ]);
        if($update) return redirect('/dashbord');
        else return 'gagal update data';
    }
}
